# icrc1_ape_20

# Verify launch

- go to initial commit
- build, get the hash, check if the canister hash in the dashboard.internetcomputer.org matches
